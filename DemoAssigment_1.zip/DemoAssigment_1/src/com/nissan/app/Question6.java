package com.nissan.app;
import java.util.*;
public class Question6 {
	 /*
    Two numbers are stored in locations i and j. Write a program to interchange the numbers.
*/
	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter first value : ");
    int firstValue = sc.nextInt();
    System.out.println("Enter second value : ");
    int secondValue = sc.nextInt();
    sc.close();
    int temp = firstValue;
    firstValue = secondValue;
    secondValue = temp;

    System.out.println("Now first value is " + firstValue + " and second value is " + secondValue);
}
}
