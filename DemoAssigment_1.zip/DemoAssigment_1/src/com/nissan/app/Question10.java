package com.nissan.app;
import java.util.*;
public class Question10 {

		 /*
	     If a five-digit number is given, write a program to reverse the number.
	    */
		public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Number : ");
	        long num = sc.nextInt();
	        long sum = 0;

	        while(num > 0) {

	            sum = (sum * 10) + (num % 10);
	            num = (num / 10);

	        }
	        System.out.println();
	        System.out.println("The reverse of digits is :" + sum);
	    }



	}

