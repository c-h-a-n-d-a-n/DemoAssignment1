package com.nissan.app;
import java.util.*;
public class Question4 {
	public static void main(String[] args) {
		/*
	    The distance between two cities (KM) is input through the keyboard.
	    Write a program to convert and print this distance in meters, feet, inches and centimeters.
	    */

 
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Input distance in Kilometers : ");
	        float km = sc.nextFloat();
	        sc.close();
	        System.out.println("Kilometer to meter : " + (km * 1000) + " meters");
	        System.out.println("Kilometer to feet : " + (km * 3280.8399) + " feets");
	        System.out.println("Kilometer to inche : " + (km * 39370.1) + " inches");
	        System.out.println("Kilometer to inche : " + (km * 100000) + " centimeters");
	    
	}
	
}
