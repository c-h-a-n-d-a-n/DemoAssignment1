package com.nissan.app;
import java.util.*;
public class Question8 {
	/*
    implement a logic to swap two numbers without using a temporary variable.
    (Asked in Nissan interview)
    */
	public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         System.out.println("Enter first and second values below : ");
         int firstVar = sc.nextInt();
         int secondVar = sc.nextInt();
        System.out.println("before swapping first variable : " + firstVar + " and Second variable " + secondVar);
        sc.close();
        firstVar = firstVar * secondVar;
        secondVar = firstVar / secondVar;
        firstVar = firstVar / secondVar;

        System.out.println("After swapping first variable : " + firstVar + " and Second variable " + secondVar);
    }
}
