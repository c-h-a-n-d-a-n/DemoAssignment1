package com.nissan.app;

public class Question1 {

	public static void main(String[] args) {
		/*
	    For 10 oranges we have to pay Rs.45 what will be the price of 1 orange.
	    You can set the status of your assignment here.
	    
	    
	    * */ 
	   
	        float number_Of_Orange = 10;
	        float total_Price = 45;
	        float one_Orange_Price = (total_Price / number_Of_Orange);
	        System.out.println(String.format("Price of one orange is : %.2f",one_Orange_Price));
	   

	}

}
