package com.nissan.app;
import java.util.*;
public class Question3 {
	/*
    Read two numbers, divide the first number by the second and print the quotient and remainder.
    You can set the status of your assignment here.
    * */

	public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number : ");
        int first_Num = sc.nextInt();
        System.out.println("Enter second number : ");
        int second_Num = sc.nextInt();

        int result = first_Num / second_Num;
        int mod = first_Num % second_Num;
        sc.close();

        System.out.println("First number divided by second number is : " + result);
        System.out.println("Remainder is " + mod);
    }
}
