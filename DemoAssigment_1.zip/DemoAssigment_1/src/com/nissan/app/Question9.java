package com.nissan.app;
import java.util.*;
public class Question9 {

    /*
    If a five-digit number is input through the keyboard, write a program to calculate the sum of its digits.
    */
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Digit : ");
        int num = sc.nextInt();
        long sum = 0;

        while(num > 0) {

            sum += (num % 10);
            num = (num / 10);

        }
        System.out.println();
        System.out.println("The sum of digits is :" + sum);
        sc.close();

    }

}
