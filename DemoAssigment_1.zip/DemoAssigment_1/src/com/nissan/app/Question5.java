package com.nissan.app;

import java.util.Scanner;

public class Question5 {
	/*
    The temperature of a city in Fahrenheit is given. Write a program to convert it into Celsius.
    You can set the status of your assignment here.
    */
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter temp in celcious : ");
        float temp = sc.nextFloat();
        System.out.println(temp+" in Fahrenheit is : " + temp * 1.8 + 32);
        sc.close();
	}
}
