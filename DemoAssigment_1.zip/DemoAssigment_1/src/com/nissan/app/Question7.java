package com.nissan.app;
import java.util.*;
public class Question7 {
	  /*
    Raju’s basic salary is given.
    His dearness allowance is 40% of the basic salary and house rent allowance is 20%.
    Calculate his total salary.
    */

	public static void main(String[] args) {
        System.out.println("Enter salary below : ");
        Scanner sc = new Scanner(System.in);

        double basicSalary = sc.nextInt();
        double rent = 0.2 * basicSalary;
        double dearness_allowance = 0.4 * basicSalary;
        double totalsalary = basicSalary + rent + dearness_allowance;

        sc.close();
        System.out.println(String.format("Total salary is %.2f per month", totalsalary ));
    }
}
