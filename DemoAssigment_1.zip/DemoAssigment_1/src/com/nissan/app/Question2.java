package com.nissan.app;

public class Question2 {

	public static void main(String[] args) {
		 /*
	    Ramu visited the bookstore to buy books for his kid. He bought notebooks for Rs.100 and
	    magic pot for Rs.50. How much money did Ramu spend in the bookstore?
	    */
	  {
	        short notebook = 100;
	        short magic_Pot = 50;
	        System.out.println("Ramu bought : " + (int)(notebook + magic_Pot));
	    }

	}

}
